import {
  ITEMS, AVATAR_COLORS, COLOR_HEX, EYE_STYLES, MASK_TYPES, POWER_UPS,
} from "./game-logic.js";
import { getItemSVG, getPowerSVG } from "./item-art.js";

const $ = (id) => document.getElementById(id);

// --- WebSocket Connection ---
const wsProto = location.protocol === "https:" ? "wss" : "ws";
const wsOverride = new URLSearchParams(location.search).get("ws");
const ws = new WebSocket(wsOverride || `${wsProto}://${location.host}`);

let myId = null;
let state = null;
let soundEnabled = true;

// --- Procedural Sound Effects via Web Audio API (Zero external files needed) ---
let audioCtx = null;
function getAudioContext() {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) audioCtx = new AudioContextClass();
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume();
  }
  return audioCtx;
}

function playSound(type) {
  if (!soundEnabled) return;
  try {
    const ctx = getAudioContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    if (type === "click") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(400, now + 0.05);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.05);
    } else if (type === "gavel") {
      // Deep wooden impact + resonant snap
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(30, now + 0.28);
      gain.gain.setValueAtTime(0.6, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.28);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.28);

      // Noise slap
      const bufferSize = ctx.sampleRate * 0.06;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      const nGain = ctx.createGain();
      nGain.gain.setValueAtTime(0.35, now);
      nGain.gain.exponentialRampToValueAtTime(0.01, now + 0.06);
      noise.connect(nGain);
      nGain.connect(ctx.destination);
      noise.start(now);
    } else if (type === "beep") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(520, now);
      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.08);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.08);
    } else if (type === "claim_unlocked") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.exponentialRampToValueAtTime(880, now + 0.25);
      gain.gain.setValueAtTime(0.35, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.25);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.25);
    } else if (type === "siren") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(280, now);
      osc.frequency.linearRampToValueAtTime(380, now + 0.15);
      osc.frequency.linearRampToValueAtTime(260, now + 0.3);
      gain.gain.setValueAtTime(0.2, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.32);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.32);
    } else if (type === "reveal") {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "triangle";
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(640, now + 0.3);
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.3);
    } else if (type === "page") {
      const bufferSize = ctx.sampleRate * 0.05;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) data[i] = Math.random() * 2 - 1;
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;
      const nGain = ctx.createGain();
      nGain.gain.setValueAtTime(0.18, now);
      nGain.gain.exponentialRampToValueAtTime(0.01, now + 0.05);
      noise.connect(nGain);
      nGain.connect(ctx.destination);
      noise.start(now);
    }
  } catch {
    // Audio context may be restricted by autoplay policy until user gesture
  }
}

// --- Operative Avatar 2D Vector Rendering ---
function eyesSVG(eyes) {
  switch (eyes) {
    case "Tired":
      return `
        <line x1="44" y1="56" x2="58" y2="56" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/>
        <line x1="62" y1="56" x2="76" y2="56" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/>
        <line x1="46" y1="60" x2="56" y2="60" stroke="#71717a" stroke-width="1.5"/>
        <line x1="64" y1="60" x2="74" y2="60" stroke="#71717a" stroke-width="1.5"/>`;
    case "Calculating":
      return `
        <ellipse cx="51" cy="56" rx="7" ry="4.5" fill="#fff" transform="rotate(-15 51 56)"/>
        <ellipse cx="69" cy="56" rx="7" ry="4.5" fill="#fff" transform="rotate(15 69 56)"/>
        <circle cx="53" cy="56" r="2.5" fill="#18181b"/>
        <circle cx="67" cy="56" r="2.5" fill="#18181b"/>`;
    case "Suspicious":
      return `
        <circle cx="51" cy="56" r="6" fill="#fff"/>
        <circle cx="69" cy="56" r="6" fill="#fff"/>
        <circle cx="54" cy="56" r="2.8" fill="#18181b"/>
        <circle cx="72" cy="56" r="2.8" fill="#18181b"/>
        <path d="M44 50 L56 52" stroke="#fff" stroke-width="2"/>
        <path d="M76 50 L64 52" stroke="#fff" stroke-width="2"/>`;
    case "Intense":
      return `
        <rect x="44" y="53" width="16" height="5" rx="1.5" fill="#fff"/>
        <rect x="60" y="53" width="16" height="5" rx="1.5" fill="#fff"/>
        <circle cx="52" cy="55.5" r="2.2" fill="#ef4444"/>
        <circle cx="68" cy="55.5" r="2.2" fill="#ef4444"/>`;
    case "Angry":
      return `
        <line x1="43" y1="49" x2="59" y2="54" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
        <line x1="77" y1="49" x2="61" y2="54" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
        <circle cx="51" cy="58" r="4.5" fill="#fff"/>
        <circle cx="69" cy="58" r="4.5" fill="#fff"/>
        <circle cx="51" cy="58" r="2" fill="#18181b"/>
        <circle cx="69" cy="58" r="2" fill="#18181b"/>`;
    case "Deadpan":
    default:
      return `
        <circle cx="51" cy="56" r="5.5" fill="#fff"/>
        <circle cx="69" cy="56" r="5.5" fill="#fff"/>
        <circle cx="51" cy="56" r="2.2" fill="#18181b"/>
        <circle cx="69" cy="56" r="2.2" fill="#18181b"/>`;
  }
}

function mouthSVG(eyes) {
  switch (eyes) {
    case "Calculating":
      return `<path d="M49 83 Q60 88 71 82" stroke="#e5e7eb" stroke-width="2.5" stroke-linecap="round" fill="none"/>`;
    case "Suspicious":
      return `<path d="M49 84 Q55 81 60 84 Q65 87 71 84" stroke="#e5e7eb" stroke-width="2.5" stroke-linecap="round" fill="none"/>`;
    case "Intense":
      return `<rect x="49" y="82" width="22" height="3" rx="1" fill="#e5e7eb"/>`;
    case "Angry":
      return `<path d="M48 88 Q60 79 72 88" stroke="#e5e7eb" stroke-width="2.8" stroke-linecap="round" fill="none"/>`;
    case "Tired":
    case "Deadpan":
    default:
      return `<line x1="50" y1="83" x2="70" y2="83" stroke="#e5e7eb" stroke-width="2.5" stroke-linecap="round"/>`;
  }
}

function maskSVG(mask, colorHex) {
  switch (mask) {
    case "Gas Mask Lower":
      return `
        <rect x="38" y="65" width="44" height="28" rx="8" fill="#22252a" stroke="#000" stroke-width="2"/>
        <circle cx="48" cy="80" r="7" fill="#475569" stroke="#0f172a" stroke-width="1.5"/>
        <circle cx="72" cy="80" r="7" fill="#475569" stroke="#0f172a" stroke-width="1.5"/>
        <circle cx="60" cy="74" r="3.5" fill="#334155"/>`;
    case "Black Cloth":
      return `
        <path d="M38 64 L82 64 L79 92 L41 92 Z" fill="#0f0f13" stroke="#27272a" stroke-width="2"/>
        <line x1="42" y1="78" x2="78" y2="78" stroke="#3f3f46" stroke-width="1.5" stroke-dasharray="4 3"/>`;
    case "Armored Plate":
      return `
        <rect x="38" y="64" width="44" height="28" rx="4" fill="#475569" stroke="#1e293b" stroke-width="2"/>
        <circle cx="43" cy="69" r="2" fill="#0f172a"/>
        <circle cx="77" cy="69" r="2" fill="#0f172a"/>
        <circle cx="43" cy="87" r="2" fill="#0f172a"/>
        <circle cx="77" cy="87" r="2" fill="#0f172a"/>
        <line x1="48" y1="78" x2="72" y2="78" stroke="#334155" stroke-width="2"/>`;
    case "Balaclava Lower":
      return `
        <path d="M36 58 Q60 50 84 58 L84 94 L36 94 Z" fill="${colorHex}" stroke="#000" stroke-width="2"/>
        <line x1="50" y1="82" x2="70" y2="82" stroke="#000" stroke-width="2.5" stroke-linecap="round"/>`;
    case "Bandana":
    default:
      return `
        <path d="M38 65 L82 65 L78 94 L42 94 Z" fill="#18181b" stroke="#000" stroke-width="2"/>
        <circle cx="83" cy="68" r="4.5" fill="#18181b" stroke="#000" stroke-width="1.5"/>
        <line x1="43" y1="74" x2="77" y2="74" stroke="#ff2447" stroke-width="2"/>
        <line x1="46" y1="82" x2="74" y2="82" stroke="#ff2447" stroke-width="2"/>`;
  }
}

function buildAvatarSVG(p) {
  const colorHex = COLOR_HEX[p.color] || "#3a3f44";
  return `<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="${escapeHtml(p.name)} Operative">
    <!-- Tactical Shoulders & Trenchcoat Collar -->
    <path d="M16 120 L32 92 Q60 84 88 92 L104 120 Z" fill="${colorHex}" stroke="#09080d" stroke-width="2.5"/>
    <path d="M48 92 L60 106 L72 92 Z" fill="#18181b" stroke="#09080d" stroke-width="1.5"/>

    <!-- Head Hood / Base -->
    <path d="M26 92 Q26 20 60 20 Q94 20 94 92 Z" fill="${colorHex}" stroke="#09080d" stroke-width="2.5"/>
    <path d="M26 92 Q26 20 60 20 L60 92 Z" fill="#000" opacity="0.18"/>

    <!-- Face Visor Recess -->
    <rect x="38" y="40" width="44" height="32" rx="9" fill="#16141c" stroke="#252130" stroke-width="1.5"/>

    <!-- Eyes (Expression) -->
    ${eyesSVG(p.eyes)}

    <!-- Unmasked Mouth (revealed when unmasked) -->
    <g class="avatar-mouth-group">
      ${mouthSVG(p.eyes)}
    </g>

    <!-- Animated Mask Group (slides down when unmasked, slides up when masked) -->
    <g class="avatar-mask-group">
      ${maskSVG(p.mask, colorHex)}
    </g>
  </svg>`;
}

function avatarCardHTML(p, masked) {
  const isMe = p.id === myId;
  return `
    <div class="avatar-card ${masked ? "masked" : "unmasked"} ${p.shieldActive ? "has-shield" : ""}">
      <div class="avatar-svg-box">
        ${buildAvatarSVG(p)}
      </div>
      <div class="avatar-name-line" title="${escapeHtml(p.name)}">
        ${escapeHtml(p.name)}${isMe ? " (You)" : ""}
      </div>
      <div>
        <span class="avatar-status-pill ${masked ? "pill-masked" : "pill-unmasked"}">
          ${masked ? "MASKED" : "UNMASKED"}
        </span>
        ${p.isHost ? '<span class="avatar-status-pill pill-host">HOST</span>' : ""}
      </div>
      ${p.hasBid ? '<span class="avatar-status-pill pill-bid-locked">BID LOCKED ✓</span>' : ""}
      ${p.shieldActive ? '<span class="avatar-status-pill pill-shield">SHIELD ARMED 🛡️</span>' : ""}
      ${p.subpoenaed ? `<div style="font-size:11px;color:#facc15;font-weight:900;margin-top:2px;">₹${p.wallet}</div>` : ""}
    </div>`;
}

function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[c]));
}

function send(obj) {
  if (ws.readyState === 1) ws.send(JSON.stringify(obj));
}

// --- Start Page Selector State ---
const sel = { color: 3, eyes: 3, mask: 0 }; // Charcoal, Deadpan, Bandana
let previewMasked = true;

function profile() {
  return {
    name: $("nameInput").value.trim() || "Operative",
    color: AVATAR_COLORS[sel.color],
    eyes: EYE_STYLES[sel.eyes],
    mask: MASK_TYPES[sel.mask],
  };
}

function renderPreview() {
  $("eyesValue").textContent = EYE_STYLES[sel.eyes];
  $("maskValue").textContent = MASK_TYPES[sel.mask];
  $("colorValue").textContent = AVATAR_COLORS[sel.color];

  const p = { ...profile(), isHost: false };
  $("avatarPreview").className = `avatar-frame ${previewMasked ? "masked" : "unmasked"}`;
  $("avatarPreview").innerHTML = buildAvatarSVG(p);

  $("maskToggleLabel").textContent = previewMasked ? "Masked" : "Unmasked";
  $("maskNote").textContent = previewMasked
    ? "Preview is MASKED — masks hide your mouth during Silent Bidding."
    : "Preview is UNMASKED — expression is visible during Discussion.";
}

function cycle(part, dir) {
  playSound("click");
  const lists = { color: AVATAR_COLORS, eyes: EYE_STYLES, mask: MASK_TYPES };
  const list = lists[part];
  sel[part] = (sel[part] + dir + list.length) % list.length;
  renderPreview();
}

document.querySelectorAll(".arrow-btn").forEach((btn) => {
  btn.addEventListener("click", () => cycle(btn.dataset.cycle, Number(btn.dataset.dir)));
});

$("randomAvatarBtn").addEventListener("click", () => {
  playSound("click");
  sel.color = Math.floor(Math.random() * AVATAR_COLORS.length);
  sel.eyes = Math.floor(Math.random() * EYE_STYLES.length);
  sel.mask = Math.floor(Math.random() * MASK_TYPES.length);
  renderPreview();
});

$("maskToggleBtn").addEventListener("click", () => {
  playSound("click");
  previewMasked = !previewMasked;
  renderPreview();
});

$("nameInput").addEventListener("input", renderPreview);
renderPreview();

// --- Panel Navigation & Screens ---
function show(id) {
  const panels = [
    "panel-setup",
    "panel-lobby",
    "panel-draft",
    "panel-game",
    "panel-black-market",
    "panel-ended",
  ];
  panels.forEach((p) => {
    $(p).hidden = p !== id;
  });
}

function showToast(text, duration = 4000) {
  const el = $("errorToast");
  el.textContent = text;
  el.hidden = false;
  setTimeout(() => { el.hidden = true; }, duration);
}

function showIntelModal(title, content) {
  playSound("reveal");
  $("intelTitle").textContent = title;
  $("intelContent").textContent = content;
  $("intelModal").hidden = false;
}
$("closeIntelBtn").addEventListener("click", () => { $("intelModal").hidden = true; });

// --- Rules Diary Book (Interactive Flip Guide) ---
const DIARY_PAGES = [
  {
    title: "1. The Narrative & Stakes",
    body: "You are a masked operative trapped by The Broker's underground syndicate. The only exit is securing classified common objects across 25 secret auctions. Wallet balances and items won exist solely inside this operation — no progression bloat or outside advantage.",
  },
  {
    title: "2. The Tactical Draft (60s)",
    body: "Before bidding starts, operatives survey a 5x5 board of 25 common items. Secretly select 10 Target Items for your personal wishlist. Opponents only ever see your selection count, never your items.",
  },
  {
    title: "3. Unmasked Discussion (3 Min)",
    body: "Each round begins with a cryptic undercover hint (e.g. 'A simple object that emits light'). Operative masks slide down, fully exposing your vector face. Use voice or comms to negotiate, bluff, or form alliances. Click 'End Discussion' early if the room agrees.",
  },
  {
    title: "4. Silent Bidding (60s)",
    body: "SILENT PROTOCOL ENGAGED. Red alert flashes, masks slide back up over your mouth, and all comms are system-muted. Submit one secret blind bid within minimum and increment rules. No second chances.",
  },
  {
    title: "5. Escalating Tie-Breaker Clash",
    body: "1. Highest Unique Bid Wins.\n2. High-Bid Tie: Item defaults to the Lowest Bidder!\n3. Double Tie: Defaults to Second-Highest Bidder.\n4. Total Deadlock: Item destroyed, cash refunded.",
  },
  {
    title: "6. Dynamic Economy & Victory",
    body: "Wallets and item targets scale strictly at Start based on connected players:\n• 2 Players: 7 items to win (₹15,000 wallet)\n• 3-4 Players: 5 items (₹12,000)\n• 5-7 Players: 4 items (₹10,000)\n• 8-10 Players: 3 items (₹8,000)",
  },
  {
    title: "7. Black Market Drops & Speed-Snap",
    body: "On Rounds 3, 6, 9, 12, 15, 18, 21, and 24, power cards drop instead of items! A 3-second countdown arms the live button. The very first click claims the card. Permanent Lockout: claiming one card permanently locks you out of future drops!",
  },
];

let diaryPage = 0;
function renderDiaryPage() {
  const p = DIARY_PAGES[diaryPage];
  $("diaryPageTitle").textContent = p.title;
  $("diaryPageText").textContent = p.body;
  $("diaryPageNum").textContent = `Page ${diaryPage + 1} / ${DIARY_PAGES.length}`;

  // Dots
  $("diaryDots").innerHTML = DIARY_PAGES.map((_, i) =>
    `<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${i === diaryPage ? "#5c1818" : "#a89a82"};margin:0 3px;"></span>`
  ).join("");
}

function flipDiary(dir) {
  playSound("page");
  const el = $("diaryPage");
  el.classList.add(dir > 0 ? "flip-up" : "flip-down");
  setTimeout(() => {
    diaryPage = Math.min(DIARY_PAGES.length - 1, Math.max(0, diaryPage + dir));
    renderDiaryPage();
    el.classList.remove("flip-up", "flip-down");
  }, 220);
}

function openDiary() {
  playSound("click");
  diaryPage = 0;
  renderDiaryPage();
  $("diaryBook").hidden = false;
}
function closeDiary() {
  playSound("click");
  $("diaryBook").hidden = true;
}

$("rulesToggleBtn").addEventListener("click", openDiary);
$("rulesBookBtn").addEventListener("click", openDiary);
$("diaryCloseBtn").addEventListener("click", closeDiary);
$("diaryNextBtn").addEventListener("click", () => { if (diaryPage < DIARY_PAGES.length - 1) flipDiary(1); });
$("diaryPrevBtn").addEventListener("click", () => { if (diaryPage > 0) flipDiary(-1); });
$("diaryBook").addEventListener("click", (e) => { if (e.target === $("diaryBook")) closeDiary(); });

// Sound Toggle
$("soundToggleBtn").addEventListener("click", () => {
  soundEnabled = !soundEnabled;
  $("soundToggleBtn").textContent = soundEnabled ? "🔊 Sound: ON" : "🔇 Sound: OFF";
  if (soundEnabled) playSound("click");
});

// Interactive Corner Hammer Gavel
$("hammerBtn").addEventListener("click", () => {
  playSound("gavel");
  $("hammerBtn").classList.add("striking");
  setTimeout(() => {
    $("hammerBtn").classList.remove("striking");
    send({ type: "find_random", ...profile() });
  }, 360);
});

// Start Page Buttons
$("playBtn").addEventListener("click", () => {
  playSound("click");
  send({ type: "find_random", ...profile() });
});

$("createBtn").addEventListener("click", () => {
  playSound("click");
  send({ type: "create", mode: "private", playerLimit: 10, ...profile() });
});

$("joinBtn").addEventListener("click", () => {
  playSound("click");
  const code = $("codeInput").value.trim().toUpperCase();
  if (!code) {
    showToast("Please enter a 4-character room code (e.g. K9X2) or create a room.");
    $("codeInput").focus();
    return;
  }
  send({ type: "join", code, ...profile() });
});

$("copyCodeBtn").addEventListener("click", () => {
  if (state?.code) {
    navigator.clipboard?.writeText(state.code);
    showToast(`Room code CODE-${state.code} copied!`);
  }
});

$("limitInput").addEventListener("input", () => {
  $("limitValue").textContent = $("limitInput").value;
  send({ type: "set_settings", mode: $("modeInput").value, playerLimit: Number($("limitInput").value) });
});

$("modeInput").addEventListener("change", () => {
  send({ type: "set_settings", mode: $("modeInput").value, playerLimit: Number($("limitInput").value) });
});

$("startBtn").addEventListener("click", () => {
  playSound("gavel");
  send({ type: "start" });
});

// In-Game Actions
$("endDiscussionBtn").addEventListener("click", () => {
  playSound("click");
  send({ type: "end_discussion" });
});

$("bidBtn").addEventListener("click", () => {
  playSound("click");
  const amt = Number($("bidInput").value);
  send({ type: "bid", amount: amt });
});

document.querySelectorAll(".bid-chip").forEach((chip) => {
  chip.addEventListener("click", () => {
    playSound("click");
    if (!state) return;
    const current = Number($("bidInput").value) || state.scaling.minBid;
    const add = Number(chip.dataset.add);
    if (add) {
      $("bidInput").value = Math.min(state.myWallet, current + add);
    }
  });
});

$("maxBidChip").addEventListener("click", () => {
  playSound("click");
  if (state) $("bidInput").value = state.myWallet;
});

$("chatSend").addEventListener("click", () => {
  const text = $("chatInput").value.trim();
  if (!text) return;
  playSound("click");
  send({ type: "chat", text });
  $("chatInput").value = "";
});
$("chatInput").addEventListener("keydown", (e) => {
  if (e.key === "Enter") $("chatSend").click();
});

// Black Market Speed-Snap Claim Button
$("bmClaimBtn").addEventListener("click", () => {
  playSound("gavel");
  send({ type: "claim_power" });
});

$("playAgainBtn").addEventListener("click", () => {
  location.reload();
});

// Power-Up Target Selection Modal Handler
let pendingPower = null;
function promptTargetForPower(powerId) {
  pendingPower = powerId;
  const powerMeta = POWER_UPS.find((p) => p.id === powerId);
  $("targetModalTitle").textContent = powerMeta ? powerMeta.name.toUpperCase() : "DEPLOY INTEL";
  $("targetModalPrompt").textContent = powerMeta ? powerMeta.actionPrompt : "Select target operative:";

  const opponents = state.players.filter((p) => p.id !== myId);
  $("targetOperativesList").innerHTML = opponents.map((op) => `
    <button class="btn-target-op" data-id="${op.id}">
      ${escapeHtml(op.name)}
    </button>
  `).join("");

  $("targetOperativesList").querySelectorAll("button").forEach((btn) => {
    btn.addEventListener("click", () => {
      playSound("click");
      $("targetModal").hidden = true;
      send({ type: "use_power", power: pendingPower, targetId: btn.dataset.id });
      pendingPower = null;
    });
  });

  $("targetModal").hidden = false;
}
$("cancelTargetBtn").addEventListener("click", () => { $("targetModal").hidden = true; });

// --- WebSocket Event Handlers ---
ws.onopen = () => {
  $("status").textContent = "Connected to Syndicate Floor";
};
ws.onclose = () => {
  $("status").textContent = "Connection Lost — Reconnecting...";
};
ws.onerror = () => {
  $("status").textContent = "Syndicate server unreachable";
};
ws.onmessage = (event) => {
  let msg;
  try { msg = JSON.parse(event.data); } catch { return; }

  if (msg.type === "joined") {
    myId = msg.playerId;
  }
  if (msg.type === "error") {
    showToast(msg.text);
    return;
  }
  if (msg.type === "notice") {
    $("status").textContent = msg.text;
  }
  if (msg.type === "intel_revealed") {
    showIntelModal(msg.title, msg.text);
  }
  if (msg.type === "state") {
    state = msg.room;
    render();
  }
};

// --- Main UI State Renderer ---
let lastPhase = null;
let lastCountdown = null;

function render() {
  if (!state) return;
  const me = state.players.find((p) => p.id === myId);

  // Play audio triggers on phase transitions
  if (lastPhase !== state.phase) {
    if (state.phase === "bidding") playSound("siren");
    else if (state.phase === "reveal") playSound("reveal");
    else if (state.phase === "black_market") playSound("claim_unlocked");
    lastPhase = state.phase;
  }

  // 1. Lobby Phase
  if (state.phase === "lobby") {
    show("panel-lobby");
    $("roomCode").textContent = state.code ? `CODE-${state.code}` : "----";
    $("lobbyPlayerCount").textContent = state.players.length;
    $("lobbyPlayerLimit").textContent = state.playerLimit;
    $("lobbyGrid").innerHTML = state.players.map((p) => avatarCardHTML(p, true)).join("");

    const isHost = me && me.id === state.hostId;
    $("hostSettings").hidden = !isHost;
    $("lobbyHint").hidden = Boolean(isHost);
    $("modeInput").value = state.mode;
    $("limitInput").value = state.playerLimit;
    $("limitValue").textContent = state.playerLimit;
  }

  // 2. Tactical Draft Phase
  else if (state.phase === "draft") {
    show("panel-draft");
    $("draftCount").textContent = `${state.myTargets.length} / 10 Selected`;
    $("draftTimer").textContent = `${state.timeLeft}s`;

    $("draftGrid").innerHTML = ITEMS.map((item) => {
      const selected = state.myTargets.includes(item.name);
      return `
        <button class="draft-card-btn ${selected ? "selected" : ""}" data-item="${escapeHtml(item.name)}">
          <div class="draft-card-svg">${getItemSVG(item.name)}</div>
          <span class="draft-card-name">${escapeHtml(item.name)}</span>
          ${selected ? '<div class="draft-check">✓</div>' : ""}
        </button>`;
    }).join("");

    $("draftGrid").querySelectorAll("button").forEach((b) => {
      b.addEventListener("click", () => {
        playSound("click");
        send({ type: "draft_select", item: b.dataset.item });
      });
    });
  }

  // 3. Black Market Drop Phase (Rounds 3, 6, 9, 12, 15, 18, 21, 24)
  else if (state.phase === "black_market") {
    show("panel-black-market");
    const bm = state.blackMarket;
    if (bm) {
      $("bmRoundTitle").textContent = `ROUND ${state.round}: SPEED-SNAP DROP`;
      $("bmPowerName").textContent = bm.power.name.toUpperCase();
      $("bmPowerDesc").textContent = bm.power.desc;
      $("bmPowerIcon").innerHTML = getPowerSVG(bm.power.id);

      if (bm.canClaim && !bm.claimedBy) {
        $("bmCountdownNum").textContent = "⚡ CLAIM!";
        $("bmCountdownStatus").textContent = "REACTION SENSORS ACTIVE — FIRST CLICK WINS!";
        const lockedOut = Boolean(state.hasClaimedPowerUp);
        $("bmClaimBtn").disabled = lockedOut;
        $("bmLockoutNotice").hidden = !lockedOut;
      } else if (bm.claimedBy) {
        $("bmCountdownNum").textContent = "SECURED";
        $("bmCountdownStatus").textContent = `CARD CLAIMED BY OPERATIVE: ${bm.claimedBy.name.toUpperCase()}`;
        $("bmClaimBtn").disabled = true;
        $("bmLockoutNotice").hidden = true;
      } else {
        $("bmCountdownNum").textContent = state.timeLeft > 0 ? state.timeLeft : "3";
        $("bmCountdownStatus").textContent = "COUNTDOWN ARMING SPEED-SNAP...";
        $("bmClaimBtn").disabled = true;
        $("bmLockoutNotice").hidden = true;

        if (state.timeLeft !== lastCountdown && state.timeLeft > 0) {
          playSound("beep");
          lastCountdown = state.timeLeft;
        }
      }
    }
  }

  // 4. Standard Auction Phases: Discussion, Silent Bidding, Reveal
  else if (["discussion", "bidding", "reveal"].includes(state.phase)) {
    show("panel-game");

    $("roundTitle").textContent = `Round ${state.round} / 25`;
    $("phaseBadge").textContent = state.phase.toUpperCase();
    $("phaseBadge").className = `phase-badge phase-${state.phase}`;
    $("gameTimer").textContent = `${state.timeLeft}s`;

    // Wallet & Target items won progress HUD
    if (me) {
      $("myWalletHUD").textContent = `₹${me.wallet.toLocaleString()}`;
      $("targetProgressHUD").textContent = `${me.won.length} / ${state.scaling.itemsToWin} Target Items Won`;
    }

    // Silent Mode Banner & Comms Mute
    const isSilent = state.phase === "bidding";
    $("silentAlertBanner").hidden = !isSilent;
    $("chatBox").hidden = isSilent;
    $("endDiscussionBtn").hidden = state.phase !== "discussion";
    $("bidBox").hidden = state.phase !== "bidding";

    // Operative Avatars Row with real-time mask sliding animation
    $("playerRow").innerHTML = state.players.map((p) => avatarCardHTML(p, state.masked)).join("");

    // Hint Card
    if (state.phase === "discussion") {
      $("hintCard").hidden = false;
      $("hintText").textContent = `"${state.hint || "..."}"`;
    } else {
      $("hintCard").hidden = true;
    }

    // Bidding Setup
    if (state.phase === "bidding" && state.scaling) {
      $("walletLine").textContent = `Wallet: ₹${state.myWallet} · Min: ₹${state.scaling.minBid} · Increment: ₹${state.scaling.increment}`;
      $("bidInput").min = state.scaling.minBid;
      $("bidInput").step = state.scaling.increment;
    }

    // 3D Card Flip Reveal
    if (state.phase === "reveal" && state.reveal) {
      $("revealCard").hidden = false;
      $("revealItem").textContent = state.reveal.item.toUpperCase();
      $("revealReason").textContent = state.reveal.reason;
      $("revealArt").innerHTML = getItemSVG(state.reveal.item);

      $("revealBids").innerHTML = state.reveal.bids.map((b) => `
        <div class="bid-card-entry ${b.isWinner ? "winner" : ""} ${b.hadShield ? "shielded" : ""}">
          <div class="bidder-name">${escapeHtml(b.name)}${b.isWinner ? " 👑" : ""}</div>
          <div class="bidder-amt">${b.amount != null ? "₹" + b.amount : "No Bid"}</div>
          ${b.hadShield ? '<div style="font-size:10px;color:#fef08a;">SHIELD USED</div>' : ""}
        </div>
      `).join("");
    } else {
      $("revealCard").hidden = true;
    }

    // Comms Chat Messages Feed
    $("chatFeed").innerHTML = state.chat.map((c) => {
      const isBroker = c.from === "Broker" || c.from === "Comms";
      return `<div class="chat-msg ${isBroker ? "broker-msg" : ""}">
        <b>${escapeHtml(c.from)}:</b> ${escapeHtml(c.text)}
      </div>`;
    }).join("");
    $("chatFeed").scrollTop = $("chatFeed").scrollHeight;

    // Tactical Inventory Bar
    if (state.myInventory && state.myInventory.length > 0) {
      $("tacticalInventoryBar").hidden = false;
      $("inventoryItems").innerHTML = state.myInventory.map((itemKey) => {
        const meta = POWER_UPS.find((p) => p.id === itemKey);
        const name = meta ? meta.name : itemKey;
        return `
          <div class="inv-item-pill">
            <span class="inv-item-name">${escapeHtml(name)}</span>
            <button class="btn-use-power" data-power="${itemKey}">USE</button>
          </div>`;
      }).join("");

      $("inventoryItems").querySelectorAll(".btn-use-power").forEach((btn) => {
        btn.addEventListener("click", () => {
          const powerId = btn.dataset.power;
          if (powerId === "shield") {
            playSound("click");
            send({ type: "use_power", power: "shield" });
          } else {
            promptTargetForPower(powerId);
          }
        });
      });
    } else {
      $("tacticalInventoryBar").hidden = true;
    }
  }

  // 5. Operation Complete / Victory Screen
  else if (state.phase === "ended") {
    show("panel-ended");
    if (state.winner) {
      $("endedHeadline").textContent = "OPERATIVE LIBERATED!";
      $("endedText").textContent = `${state.winner.name} collected the required items and earned freedom from The Broker.`;
      $("endedWonList").innerHTML = state.winner.won.map((itemName) => `
        <div style="background:#1a1524;border:1px solid var(--gold);border-radius:8px;padding:8px;text-align:center;">
          <div style="width:48px;height:48px;margin:0 auto;">${getItemSVG(itemName)}</div>
          <div style="font-size:11px;font-weight:800;margin-top:4px;">${escapeHtml(itemName)}</div>
        </div>
      `).join("");
    } else {
      $("endedHeadline").textContent = "OPERATION DEADLOCK";
      $("endedText").textContent = "All 25 rounds concluded without any operative reaching the target items threshold.";
      $("endedWonList").innerHTML = "";
    }
  }
}
