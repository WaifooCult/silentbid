/**
 * 2D Vector Item Artwork for SILENT BID.
 * Pure SVG illustrations with dark-mode syndicate noir styling,
 * neon highlights (crimson #ff2447, cyan #22d3ee, gold #f5c518),
 * drop shadows, and clean vector strokes.
 */

export const ITEM_ICONS = {
  Candle: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="50" cy="85" rx="36" ry="7" fill="#1b120c" stroke="#d97706" stroke-width="2.5"/>
    <path d="M78 84 C88 84 92 74 86 66 C80 58 70 64 68 74" fill="none" stroke="#d97706" stroke-width="3" stroke-linecap="round"/>
    <rect x="42" y="38" width="16" height="46" rx="2" fill="#fef3c7" stroke="#b45309" stroke-width="2"/>
    <path d="M42 46 Q46 54 44 64" stroke="#f59e0b" stroke-width="2.5" stroke-linecap="round"/>
    <path d="M54 42 Q58 50 56 60" stroke="#f59e0b" stroke-width="2.5" stroke-linecap="round"/>
    <line x1="50" y1="38" x2="50" y2="30" stroke="#1c1917" stroke-width="2" stroke-linecap="round"/>
    <circle cx="50" cy="22" r="14" fill="#fbbf24" opacity="0.25"/>
    <path d="M50 14 C54 22 57 26 55 30 C53 34 47 34 45 30 C43 26 46 22 50 14 Z" fill="#f59e0b" stroke="#ef4444" stroke-width="1.5"/>
    <ellipse cx="50" cy="28" rx="2.5" ry="4" fill="#fef08a"/>
  </svg>`,

  Flashlight: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M26 78 L54 50 L64 60 L36 88 Z" fill="#1f2937" stroke="#374151" stroke-width="2"/>
    <line x1="32" y1="72" x2="38" y2="78" stroke="#0ea5e9" stroke-width="2"/>
    <line x1="38" y1="66" x2="44" y2="72" stroke="#0ea5e9" stroke-width="2"/>
    <line x1="44" y1="60" x2="50" y2="66" stroke="#0ea5e9" stroke-width="2"/>
    <path d="M52 48 L68 32 L82 46 L66 62 Z" fill="#111827" stroke="#0ea5e9" stroke-width="2.5"/>
    <line x1="68" y1="32" x2="82" y2="46" stroke="#22d3ee" stroke-width="4" stroke-linecap="round"/>
    <polygon points="75,39 96,18 100,54 82,46" fill="#22d3ee" opacity="0.28"/>
    <circle cx="31" cy="83" r="3" fill="#e11d48"/>
  </svg>`,

  Lantern: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M50 12 C38 12 34 22 34 28 L66 28 C66 22 62 12 50 12 Z" fill="#27272a" stroke="#d97706" stroke-width="2"/>
    <path d="M50 4 C44 4 40 8 40 12 L60 12 C60 8 56 4 50 4 Z" fill="none" stroke="#d97706" stroke-width="2.5"/>
    <rect x="36" y="28" width="28" height="44" rx="4" fill="#fef08a" opacity="0.3" stroke="#52525b" stroke-width="2"/>
    <path d="M50 42 C54 48 56 52 54 56 C52 60 48 60 46 56 C44 52 46 48 50 42 Z" fill="#f59e0b" stroke="#ef4444" stroke-width="1.5"/>
    <line x1="40" y1="28" x2="40" y2="72" stroke="#3f3f46" stroke-width="2"/>
    <line x1="60" y1="28" x2="60" y2="72" stroke="#3f3f46" stroke-width="2"/>
    <rect x="30" y="72" width="40" height="14" rx="3" fill="#18181b" stroke="#d97706" stroke-width="2"/>
  </svg>`,

  Knife: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M22 80 L38 64 L46 72 L30 88 Z" fill="#292524" stroke="#78716c" stroke-width="2"/>
    <line x1="28" y1="74" x2="34" y2="80" stroke="#dc2626" stroke-width="2"/>
    <rect x="36" y="60" width="16" height="5" transform="rotate(-45 36 60)" fill="#78716c"/>
    <path d="M44 58 L78 24 C84 20 88 18 90 14 C82 22 74 26 68 28 L40 54 Z" fill="#e2e8f0" stroke="#94a3b8" stroke-width="2"/>
    <path d="M50 50 L84 18 C78 28 66 38 48 54 Z" fill="#cbd5e1"/>
    <line x1="56" y1="42" x2="72" y2="26" stroke="#ef4444" stroke-width="1.5" stroke-dasharray="3 3"/>
  </svg>`,

  "Wine Glass": `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="50" cy="88" rx="20" ry="4" fill="#334155" stroke="#94a3b8" stroke-width="2"/>
    <line x1="50" y1="62" x2="50" y2="88" stroke="#94a3b8" stroke-width="3" stroke-linecap="round"/>
    <path d="M30 24 Q30 62 50 62 Q70 62 70 24 Z" fill="#1e293b" opacity="0.6" stroke="#94a3b8" stroke-width="2"/>
    <path d="M33 34 Q33 58 50 58 Q67 58 67 34 Q50 37 33 34 Z" fill="#be123c" stroke="#e11d48" stroke-width="1.5"/>
    <ellipse cx="44" cy="38" rx="2" ry="5" fill="#fda4af" opacity="0.75" transform="rotate(-15 44 38)"/>
  </svg>`,

  "Gold Bar": `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <polygon points="26,64 74,64 86,44 38,44" fill="#fbbf24" stroke="#d97706" stroke-width="2"/>
    <polygon points="26,64 74,64 68,78 18,78" fill="#d97706" stroke="#b45309" stroke-width="2"/>
    <polygon points="18,78 26,64 38,44 30,58" fill="#b45309" stroke="#78350f" stroke-width="1.5"/>
    <polygon points="34,50 68,50 74,47 40,47" fill="#fef08a" opacity="0.7"/>
    <text x="44" y="58" font-size="7" font-weight="900" fill="#78350f" letter-spacing="1">999.9</text>
  </svg>`,

  "Gold Coin": `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="50" cy="50" rx="34" ry="34" fill="#fbbf24" stroke="#b45309" stroke-width="3"/>
    <ellipse cx="50" cy="50" rx="28" ry="28" fill="#f59e0b" stroke="#d97706" stroke-width="2" stroke-dasharray="4 2"/>
    <circle cx="50" cy="50" rx="18" ry="18" fill="#d97706" opacity="0.4"/>
    <path d="M42 45 L50 37 L58 45 L50 53 Z" fill="#fef08a"/>
    <text x="45" y="66" font-size="12" font-weight="900" fill="#78350f">₹</text>
  </svg>`,

  Notebook: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="26" y="16" width="52" height="68" rx="4" fill="#1c1917" stroke="#dc2626" stroke-width="2.5"/>
    <line x1="34" y1="16" x2="34" y2="84" stroke="#44403c" stroke-width="3"/>
    <rect x="66" y="16" width="6" height="68" fill="#b91c1c"/>
    <rect x="40" y="36" width="30" height="12" fill="#292524" stroke="#78716c"/>
    <text x="42" y="45" font-size="6" font-weight="900" fill="#ef4444" letter-spacing="1">SECRET</text>
    <line x1="40" y1="56" x2="68" y2="56" stroke="#57534e" stroke-width="1.5"/>
    <line x1="40" y1="64" x2="62" y2="64" stroke="#57534e" stroke-width="1.5"/>
  </svg>`,

  Book: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M22 24 C36 18 48 24 50 28 C52 24 64 18 78 24 L78 74 C64 68 52 74 50 78 C48 74 36 68 22 74 Z" fill="#7f1d1d" stroke="#d97706" stroke-width="2.5"/>
    <path d="M26 26 C38 21 48 26 50 30 C52 26 62 21 74 26 L74 71 C62 66 52 71 50 75 C48 71 38 66 26 71 Z" fill="#fef3c7" stroke="#d97706" stroke-width="1"/>
    <line x1="50" y1="28" x2="50" y2="78" stroke="#b45309" stroke-width="2"/>
    <path d="M50 34 C50 50 56 60 54 86" stroke="#dc2626" stroke-width="3" fill="none"/>
  </svg>`,

  Hammer: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="46" y="36" width="8" height="52" rx="3" fill="#78350f" stroke="#451a03" stroke-width="1.5" transform="rotate(-30 46 36)"/>
    <rect x="30" y="24" width="44" height="20" rx="4" fill="#1e293b" stroke="#e2e8f0" stroke-width="2" transform="rotate(-30 30 24)"/>
    <rect x="26" y="22" width="6" height="24" rx="2" fill="#f59e0b" transform="rotate(-30 26 22)"/>
    <rect x="66" y="4" width="6" height="24" rx="2" fill="#f59e0b" transform="rotate(-30 66 4)"/>
  </svg>`,

  Key: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="34" cy="34" r="16" fill="none" stroke="#f59e0b" stroke-width="4"/>
    <circle cx="34" cy="34" r="8" fill="#1c1917" stroke="#b45309" stroke-width="2"/>
    <path d="M46 46 L76 76" stroke="#f59e0b" stroke-width="5" stroke-linecap="round"/>
    <line x1="66" y1="66" x2="74" y2="58" stroke="#f59e0b" stroke-width="4" stroke-linecap="round"/>
    <line x1="74" y1="74" x2="80" y2="68" stroke="#f59e0b" stroke-width="4" stroke-linecap="round"/>
  </svg>`,

  Padlock: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M34 46 V32 C34 22 42 16 50 16 C58 16 66 22 66 32 V46" fill="none" stroke="#f59e0b" stroke-width="6" stroke-linecap="round"/>
    <rect x="26" y="44" width="48" height="42" rx="6" fill="#334155" stroke="#94a3b8" stroke-width="2.5"/>
    <circle cx="50" cy="62" r="4" fill="#0f172a"/>
    <polygon points="48,64 52,64 54,74 46,74" fill="#0f172a"/>
    <line x1="30" y1="50" x2="70" y2="50" stroke="#475569" stroke-width="1.5"/>
  </svg>`,

  Hourglass: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="24" y="14" width="52" height="8" rx="2" fill="#78350f" stroke="#d97706" stroke-width="2"/>
    <rect x="24" y="78" width="52" height="8" rx="2" fill="#78350f" stroke="#d97706" stroke-width="2"/>
    <path d="M30 22 C30 46 46 50 50 50 C54 50 70 46 70 22 Z" fill="#0284c7" opacity="0.25" stroke="#38bdf8" stroke-width="1.5"/>
    <path d="M30 78 C30 54 46 50 50 50 C54 50 70 54 70 78 Z" fill="#0284c7" opacity="0.25" stroke="#38bdf8" stroke-width="1.5"/>
    <path d="M36 32 Q50 36 64 32 L50 50 Z" fill="#f59e0b"/>
    <path d="M42 76 Q50 68 58 76 Z" fill="#f59e0b"/>
    <line x1="50" y1="50" x2="50" y2="72" stroke="#fbbf24" stroke-width="1.5" stroke-dasharray="2 2"/>
  </svg>`,

  "Pocket Watch": `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="12" r="6" fill="none" stroke="#f59e0b" stroke-width="2.5"/>
    <rect x="46" y="16" width="8" height="6" fill="#d97706"/>
    <circle cx="50" cy="54" r="34" fill="#1e293b" stroke="#f59e0b" stroke-width="3"/>
    <circle cx="50" cy="54" r="28" fill="#fef3c7" stroke="#b45309" stroke-width="1.5"/>
    <line x1="50" y1="54" x2="50" y2="34" stroke="#0f172a" stroke-width="2.5" stroke-linecap="round"/>
    <line x1="50" y1="54" x2="64" y2="54" stroke="#dc2626" stroke-width="2" stroke-linecap="round"/>
    <circle cx="50" cy="54" r="2.5" fill="#f59e0b"/>
  </svg>`,

  Wallet: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="22" y="28" width="56" height="48" rx="6" fill="#1c1917" stroke="#78716c" stroke-width="2"/>
    <path d="M26 30 Q50 20 74 30 L74 40 L26 40 Z" fill="#15803d" stroke="#22c55e" stroke-width="1.5"/>
    <rect x="20" y="36" width="60" height="42" rx="6" fill="#292524" stroke="#a8a29e" stroke-width="2"/>
    <path d="M60 48 H80 V66 H60 C56 66 56 48 60 48 Z" fill="#1c1917" stroke="#f59e0b" stroke-width="2"/>
    <circle cx="68" cy="57" r="3" fill="#f59e0b"/>
  </svg>`,

  Compass: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="50" r="36" fill="#1e293b" stroke="#d97706" stroke-width="3"/>
    <circle cx="50" cy="50" r="30" fill="#0f172a" stroke="#475569" stroke-width="1.5"/>
    <polygon points="50,22 56,50 50,46" fill="#ef4444"/>
    <polygon points="50,22 44,50 50,46" fill="#dc2626"/>
    <polygon points="50,78 56,50 50,54" fill="#cbd5e1"/>
    <polygon points="50,78 44,50 50,54" fill="#94a3b8"/>
    <text x="47" y="20" font-size="8" font-weight="900" fill="#ef4444">N</text>
  </svg>`,

  Map: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M20 26 L40 18 L60 26 L80 18 L80 74 L60 82 L40 74 L20 82 Z" fill="#fef3c7" stroke="#b45309" stroke-width="2"/>
    <line x1="40" y1="18" x2="40" y2="74" stroke="#d97706" stroke-width="1.5" stroke-dasharray="3 3"/>
    <line x1="60" y1="26" x2="60" y2="82" stroke="#d97706" stroke-width="1.5" stroke-dasharray="3 3"/>
    <path d="M30 46 Q44 38 52 50 T68 44" fill="none" stroke="#0284c7" stroke-width="2"/>
    <line x1="66" y1="58" x2="74" y2="66" stroke="#ef4444" stroke-width="3"/>
    <line x1="74" y1="58" x2="66" y2="66" stroke="#ef4444" stroke-width="3"/>
  </svg>`,

  Rope: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="50" cy="50" rx="30" ry="24" fill="none" stroke="#d97706" stroke-width="6" stroke-dasharray="7 3"/>
    <ellipse cx="50" cy="54" rx="26" ry="20" fill="none" stroke="#b45309" stroke-width="6" stroke-dasharray="7 3"/>
    <rect x="42" y="32" width="16" height="38" rx="3" fill="#78350f" stroke="#451a03" stroke-width="2"/>
    <line x1="42" y1="40" x2="58" y2="40" stroke="#fef3c7" stroke-width="2"/>
    <line x1="42" y1="48" x2="58" y2="48" stroke="#fef3c7" stroke-width="2"/>
    <line x1="42" y1="56" x2="58" y2="56" stroke="#fef3c7" stroke-width="2"/>
  </svg>`,

  Chain: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="22" y="38" width="28" height="24" rx="10" fill="none" stroke="#94a3b8" stroke-width="5" transform="rotate(-30 22 38)"/>
    <rect x="42" y="42" width="28" height="20" rx="9" fill="none" stroke="#cbd5e1" stroke-width="4.5"/>
    <rect x="58" y="32" width="28" height="24" rx="10" fill="none" stroke="#94a3b8" stroke-width="5" transform="rotate(30 58 32)"/>
  </svg>`,

  Ring: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="50" cy="62" rx="28" ry="24" fill="none" stroke="#fbbf24" stroke-width="6"/>
    <ellipse cx="50" cy="62" rx="28" ry="24" fill="none" stroke="#b45309" stroke-width="2"/>
    <polygon points="40,24 60,24 68,36 32,36" fill="#f59e0b" stroke="#78350f" stroke-width="2"/>
    <polygon points="44,16 56,16 64,24 36,24" fill="#0f172a" stroke="#22d3ee" stroke-width="2"/>
    <circle cx="50" cy="20" r="2" fill="#22d3ee"/>
  </svg>`,

  Camera: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="18" y="34" width="64" height="44" rx="6" fill="#18181b" stroke="#52525b" stroke-width="2"/>
    <rect x="18" y="34" width="64" height="12" fill="#71717a"/>
    <rect x="28" y="24" width="14" height="10" fill="#a1a1aa" stroke="#52525b"/>
    <circle cx="70" cy="28" r="4" fill="#ef4444"/>
    <circle cx="50" cy="56" r="18" fill="#27272a" stroke="#0ea5e9" stroke-width="3"/>
    <circle cx="50" cy="56" r="11" fill="#0f172a" stroke="#22d3ee" stroke-width="2"/>
    <ellipse cx="46" cy="52" rx="3" ry="2" fill="#fff" opacity="0.8"/>
  </svg>`,

  Mirror: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <ellipse cx="50" cy="44" rx="26" ry="32" fill="#0284c7" opacity="0.3" stroke="#d97706" stroke-width="4"/>
    <ellipse cx="50" cy="44" rx="22" ry="28" fill="#e0f2fe" stroke="#38bdf8" stroke-width="1.5"/>
    <line x1="38" y1="28" x2="62" y2="60" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
    <rect x="47" y="74" width="6" height="20" rx="3" fill="#b45309" stroke="#78350f" stroke-width="1.5"/>
    <circle cx="50" cy="94" r="3" fill="#d97706"/>
  </svg>`,

  Bottle: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="44" y="14" width="12" height="10" fill="#78350f" stroke="#451a03"/>
    <path d="M42 24 L58 24 L58 36 L68 46 L68 84 L32 84 L32 46 L42 36 Z" fill="#064e3b" stroke="#10b981" stroke-width="2"/>
    <rect x="38" y="52" width="24" height="22" rx="2" fill="#fef3c7" stroke="#b45309"/>
    <line x1="42" y1="58" x2="58" y2="58" stroke="#dc2626" stroke-width="1.5"/>
    <line x1="42" y1="64" x2="54" y2="64" stroke="#78350f" stroke-width="1"/>
  </svg>`,

  Mug: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="26" y="32" width="44" height="50" rx="6" fill="#1e293b" stroke="#94a3b8" stroke-width="2.5"/>
    <path d="M70 42 C82 42 86 52 86 60 C86 68 80 72 70 72" fill="none" stroke="#94a3b8" stroke-width="4" stroke-linecap="round"/>
    <path d="M38 24 Q42 16 38 10" fill="none" stroke="#64748b" stroke-width="2" stroke-linecap="round"/>
    <path d="M50 24 Q54 16 50 10" fill="none" stroke="#64748b" stroke-width="2" stroke-linecap="round"/>
    <line x1="32" y1="44" x2="64" y2="44" stroke="#e11d48" stroke-width="2"/>
  </svg>`,

  Matchbox: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <rect x="22" y="32" width="56" height="42" rx="3" fill="#1c1917" stroke="#d97706" stroke-width="2"/>
    <rect x="22" y="64" width="56" height="10" fill="#78350f" stroke="#451a03"/>
    <rect x="36" y="22" width="42" height="32" rx="2" fill="#fef3c7" stroke="#b45309" stroke-width="1.5"/>
    <line x1="46" y1="30" x2="46" y2="46" stroke="#d97706" stroke-width="2.5"/>
    <circle cx="46" cy="28" r="3" fill="#dc2626"/>
    <line x1="56" y1="30" x2="56" y2="46" stroke="#d97706" stroke-width="2.5"/>
    <circle cx="56" cy="28" r="3" fill="#dc2626"/>
    <text x="26" y="52" font-size="9" font-weight="900" fill="#ef4444" letter-spacing="1">STRIKE</text>
  </svg>`,
};

export const POWER_ICONS = {
  wiretap: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="50" r="44" fill="#082f49" stroke="#0ea5e9" stroke-width="2.5"/>
    <path d="M26 50 C26 30 40 22 50 22 C60 22 74 30 74 50" fill="none" stroke="#22d3ee" stroke-width="5" stroke-linecap="round"/>
    <rect x="22" y="46" width="10" height="20" rx="5" fill="#0284c7" stroke="#38bdf8" stroke-width="2"/>
    <rect x="68" y="46" width="10" height="20" rx="5" fill="#0284c7" stroke="#38bdf8" stroke-width="2"/>
    <path d="M72 64 C72 74 62 80 50 80" fill="none" stroke="#22d3ee" stroke-width="3" stroke-linecap="round"/>
    <circle cx="48" cy="80" r="4" fill="#ef4444"/>
    <line x1="40" y1="52" x2="40" y2="60" stroke="#22d3ee" stroke-width="2" stroke-linecap="round"/>
    <line x1="46" y1="46" x2="46" y2="66" stroke="#22d3ee" stroke-width="2" stroke-linecap="round"/>
    <line x1="52" y1="42" x2="52" y2="70" stroke="#22d3ee" stroke-width="2" stroke-linecap="round"/>
    <line x1="58" y1="48" x2="58" y2="64" stroke="#22d3ee" stroke-width="2" stroke-linecap="round"/>
  </svg>`,

  subpoena: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="50" r="44" fill="#3b0764" stroke="#a855f7" stroke-width="2.5"/>
    <rect x="26" y="20" width="48" height="60" rx="4" fill="#fef3c7" stroke="#d97706" stroke-width="2"/>
    <line x1="34" y1="32" x2="66" y2="32" stroke="#451a03" stroke-width="2"/>
    <line x1="34" y1="40" x2="66" y2="40" stroke="#451a03" stroke-width="2"/>
    <line x1="34" y1="48" x2="58" y2="48" stroke="#451a03" stroke-width="2"/>
    <circle cx="50" cy="62" r="10" fill="#dc2626" opacity="0.85"/>
    <polygon points="50,56 52,60 56,62 52,64 50,68 48,64 44,62 48,60" fill="#fef08a"/>
    <text x="24" y="88" font-size="8" font-weight="900" fill="#facc15" letter-spacing="1">SUBPOENA</text>
  </svg>`,

  shield: `<svg viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
    <circle cx="50" cy="50" r="44" fill="#450a0a" stroke="#ef4444" stroke-width="2.5"/>
    <path d="M50 18 L76 28 C76 56 64 74 50 84 C36 74 24 56 24 28 Z" fill="#991b1b" stroke="#f59e0b" stroke-width="3"/>
    <path d="M50 26 L70 34 C70 56 60 70 50 78 C40 70 30 56 30 34 Z" fill="#7f1d1d"/>
    <polygon points="50,34 56,48 44,48" fill="#fbbf24"/>
    <polygon points="50,52 62,64 50,68 38,64" fill="#fbbf24"/>
  </svg>`,
};

export function getItemSVG(name) {
  return ITEM_ICONS[name] || `<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="40" fill="#333"/><text x="40" y="55" fill="#fff" font-size="14">?</text></svg>`;
}

export function getPowerSVG(id) {
  return POWER_ICONS[id] || `<svg viewBox="0 0 100 100"><rect width="100" height="100" rx="20" fill="#222"/></svg>`;
}
