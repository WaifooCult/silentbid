/**
 * Silent Bid — multiplayer authoritative server (Node + WebSocket).
 * Owns timers, chat muting, secret bids, Black Market power drops,
 * tie-breaker escalation, and win conditions.
 */
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { WebSocketServer } from "ws";
import {
  ITEMS, scalingFor, sanitizeName, makeRoomCode, resolveBids,
  discussionShouldEnd, isValidBid, isBlackMarketRound, POWER_UPS,
} from "../game-logic.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, "..");
const PORT = process.env.PORT || 8080;

const MIME = {
  ".html": "text/html",
  ".css": "text/css",
  ".js": "text/javascript",
  ".json": "application/json",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".svg": "image/svg+xml",
  ".ico": "image/x-icon",
};

const CLIENT_DIR = path.join(ROOT, "client");

function resolveFile(rawUrl) {
  let urlPath = rawUrl.split("?")[0];
  if (urlPath === "/" || urlPath === "/client" || urlPath === "/client/") {
    return path.join(CLIENT_DIR, "index.html");
  }
  // If explicitly requesting /client/...
  if (urlPath.startsWith("/client/")) {
    const candidate = path.normalize(path.join(CLIENT_DIR, urlPath.slice(8)));
    if (candidate.startsWith(CLIENT_DIR) && fs.existsSync(candidate) && fs.statSync(candidate).isFile()) {
      return candidate;
    }
  }
  // Try in client dir (e.g. /style.css, /app.js, /item-art.js)
  const inClient = path.normalize(path.join(CLIENT_DIR, urlPath));
  if (inClient.startsWith(CLIENT_DIR) && fs.existsSync(inClient) && fs.statSync(inClient).isFile()) {
    return inClient;
  }
  // Try in ROOT (e.g. /game-logic.js)
  const inRoot = path.normalize(path.join(ROOT, urlPath));
  if (inRoot.startsWith(ROOT) && fs.existsSync(inRoot) && fs.statSync(inRoot).isFile()) {
    return inRoot;
  }
  return null;
}

const server = http.createServer((req, res) => {
  const file = resolveFile(req.url);
  if (!file) {
    res.writeHead(404, { "Content-Type": "text/plain" });
    res.end("Not found");
    return;
  }
  fs.readFile(file, (err, data) => {
    if (err) {
      res.writeHead(500, { "Content-Type": "text/plain" });
      res.end("Internal error");
      return;
    }
    res.writeHead(200, { "Content-Type": MIME[path.extname(file)] || "text/plain" });
    res.end(data);
  });
});

const wss = new WebSocketServer({ server });
const rooms = new Map(); // code -> room
let playerSeq = 0;

function publicRoom(room, forPlayerId) {
  const me = room.players.find((p) => p.id === forPlayerId);
  return {
    code: room.code,
    mode: room.mode,
    hostId: room.hostId,
    playerLimit: room.playerLimit,
    phase: room.phase,
    round: room.round,
    totalRounds: 25,
    roundItem: (room.phase === "reveal" || room.phase === "ended") ? room.roundItem : null,
    hint: room.phase === "discussion" ? room.roundItem?.hint : undefined,
    masked: room.phase === "bidding" || room.phase === "reveal" || room.phase === "black_market" || room.phase === "lobby",
    timeLeft: room.timeLeft,
    reveal: room.reveal,
    scaling: room.scaling,
    blackMarket: room.blackMarket,
    myTargets: me ? [...me.targets] : [],
    myInventory: me ? [...me.inventory] : [],
    myWallet: me ? me.wallet : 0,
    hasClaimedPowerUp: me ? Boolean(me.hasClaimedPowerUp) : false,
    shieldActive: me ? Boolean(me.shieldActive) : false,
    players: room.players.map((p) => ({
      id: p.id,
      name: p.name,
      color: p.color,
      eyes: p.eyes,
      mask: p.mask,
      wallet: (p.id === forPlayerId || p.subpoenaed) ? p.wallet : null,
      subpoenaed: Boolean(p.subpoenaed),
      won: p.won,
      targetCount: p.targets.length,
      isHost: p.id === room.hostId,
      endDiscussion: p.endDiscussion,
      hasBid: p.hasBid,
      shieldActive: Boolean(p.shieldActive),
      hasClaimedPowerUp: Boolean(p.hasClaimedPowerUp),
    })),
    winner: room.winner,
    chat: room.chat.slice(-50),
  };
}

function broadcast(room, msg) {
  const data = JSON.stringify(msg);
  for (const p of room.players) {
    if (p.ws.readyState === 1) p.ws.send(data);
  }
  broadcastState(room);
}

function broadcastState(room) {
  for (const p of room.players) {
    if (p.ws.readyState === 1) {
      p.ws.send(JSON.stringify({ type: "state", room: publicRoom(room, p.id) }));
    }
  }
}

function clearTimer(room) {
  if (room.timer) {
    clearInterval(room.timer);
    room.timer = null;
  }
}

function startTimer(room, seconds, onDone) {
  clearTimer(room);
  room.timeLeft = seconds;
  room.timer = setInterval(() => {
    room.timeLeft -= 1;
    if (room.timeLeft <= 0) {
      clearTimer(room);
      onDone();
    } else {
      broadcastState(room);
    }
  }, 1000);
}

function shuffledItems() {
  const items = [...ITEMS];
  for (let i = items.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [items[i], items[j]] = [items[j], items[i]];
  }
  return items;
}

function startDraft(room) {
  room.phase = "draft";
  room.round = 0;
  room.roundItems = shuffledItems();
  room.itemCursor = 0;
  room.players.forEach((p) => {
    p.targets = [];
    p.inventory = [];
    p.hasClaimedPowerUp = false;
    p.shieldActive = false;
    p.subpoenaed = false;
  });
  broadcast(room, { type: "notice", text: "Draft Board: Select your 10 target items (60s)." });
  startTimer(room, 60, () => nextRoundOrEnd(room));
}

function nextRoundOrEnd(room) {
  if (room.round >= 25) return endGame(room);
  room.round += 1;

  // Check if this round is a Black Market drop round
  if (isBlackMarketRound(room.round)) {
    return startBlackMarket(room);
  }

  // Standard item auction round
  startStandardRound(room);
}

function startBlackMarket(room) {
  room.phase = "black_market";
  room.roundItem = null;
  room.reveal = null;

  // Select a random power-up card
  const power = POWER_UPS[Math.floor(Math.random() * POWER_UPS.length)];
  room.blackMarket = {
    power,
    countdown: 3,
    canClaim: false,
    claimedBy: null,
  };

  room.chat.push({
    from: "Broker",
    text: `⚡ BLACK MARKET DROP! Round ${room.round}: Classified [${power.name}] detected. Stand by for speed-snap!`,
  });
  broadcast(room, {
    type: "notice",
    text: `Round ${room.round}: Black Market Drop — ${power.name}! 3-second speed-snap countdown.`,
  });

  // 3-second countdown
  startTimer(room, 3, () => {
    room.blackMarket.countdown = 0;
    room.blackMarket.canClaim = true;
    broadcast(room, { type: "notice", text: `⚡ SPEED-SNAP ACTIVE! Claim the ${power.name} card NOW!` });

    // 8-second claim window
    startTimer(room, 8, () => {
      if (!room.blackMarket.claimedBy) {
        broadcast(room, { type: "notice", text: "Time expired! The classified intel was destroyed." });
      }
      // Brief pause then proceed
      setTimeout(() => {
        nextRoundOrEnd(room);
      }, 2500);
    });
  });
}

function startStandardRound(room) {
  room.phase = "discussion";
  room.roundItem = room.roundItems[room.itemCursor % room.roundItems.length];
  room.itemCursor += 1;
  room.reveal = null;
  room.blackMarket = null;

  // Reset round-specific flags
  room.players.forEach((p) => {
    p.endDiscussion = false;
    p.hasBid = false;
    p.currentBid = null;
    p.subpoenaed = false;
  });

  room.chat.push({
    from: "Broker",
    text: `Round ${room.round}/25 — Undercover hint: "${room.roundItem.hint}"`,
  });
  broadcast(room, {
    type: "notice",
    text: `Round ${room.round}: Discussion phase (3 min). Masks down. Form alliances or bluff.`,
  });

  startTimer(room, 180, () => startBidding(room));
}

function startBidding(room) {
  room.phase = "bidding";
  broadcast(room, {
    type: "notice",
    text: "SILENT PROTOCOL ENGAGED — Masks up. Chat muted. Submit your secret blind bid (60s).",
  });
  startTimer(room, 60, () => doReveal(room));
}

function doReveal(room) {
  room.phase = "reveal";
  const bids = room.players
    .filter((p) => p.currentBid != null)
    .map((p) => ({ playerId: p.id, amount: p.currentBid }));

  // Collect shielded players
  const shieldedPlayerIds = room.players.filter((p) => p.shieldActive).map((p) => p.id);

  const result = resolveBids(bids, room.scaling.minBid, shieldedPlayerIds);
  let winnerPlayer = null;

  if (result.winnerId) {
    winnerPlayer = room.players.find((p) => p.id === result.winnerId);
    const bid = bids.find((b) => b.playerId === result.winnerId);
    if (winnerPlayer && bid) {
      winnerPlayer.wallet -= bid.amount;
      winnerPlayer.won.push(room.roundItem.name);
    }
  }

  // Reset shields
  room.players.forEach((p) => { p.shieldActive = false; });

  room.reveal = {
    item: room.roundItem.name,
    hint: room.roundItem.hint,
    bids: room.players.map((p) => ({
      name: p.name,
      amount: p.currentBid,
      isWinner: winnerPlayer ? p.id === winnerPlayer.id : false,
      hadShield: shieldedPlayerIds.includes(p.id),
    })),
    winnerName: winnerPlayer ? winnerPlayer.name : null,
    rule: result.rule,
    reason: result.reason,
  };

  broadcast(room, { type: "notice", text: result.reason });

  // Check victory condition
  const champion = room.players.find((p) => p.won.length >= room.scaling.itemsToWin);

  startTimer(room, 15, () => {
    if (champion) {
      return endGame(room, champion);
    }
    nextRoundOrEnd(room);
  });
}

function endGame(room, champion) {
  room.phase = "ended";
  if (!champion) {
    // If 25 rounds complete without threshold, operative with most target items or most items wins
    const sorted = [...room.players].sort((a, b) => b.won.length - a.won.length);
    champion = sorted[0]?.won.length > 0 ? sorted[0] : null;
  }
  room.winner = champion ? { name: champion.name, won: champion.won, id: champion.id } : null;
  broadcast(room, {
    type: "notice",
    text: champion ? `OPERATION CONCLUDED: ${champion.name} secured freedom!` : "Operation concluded. No operative reached the target threshold.",
  });
  clearTimer(room);
}

function createRoom(ws, msg) {
  const code = makeRoomCode();
  const room = {
    code,
    mode: msg.mode === "public" ? "public" : "private",
    hostId: null,
    playerLimit: Math.min(10, Math.max(2, msg.playerLimit || 10)),
    phase: "lobby",
    players: [],
    chat: [],
    timer: null,
    timeLeft: 0,
    round: 0,
    roundItems: [],
    itemCursor: 0,
    roundItem: null,
    reveal: null,
    blackMarket: null,
    scaling: null,
    winner: null,
  };
  rooms.set(code, room);
  joinRoom(ws, { ...msg, code }, room, true);
}

function joinRoom(ws, msg, existingRoom, isNew) {
  const room = existingRoom || rooms.get(String(msg.code || "").toUpperCase());
  if (!room) {
    ws.send(JSON.stringify({ type: "error", text: "Room not found. Check the room code." }));
    return;
  }
  if (room.phase !== "lobby") {
    ws.send(JSON.stringify({ type: "error", text: "That operation has already commenced." }));
    return;
  }
  if (room.players.length >= room.playerLimit) {
    ws.send(JSON.stringify({ type: "error", text: "Operation roster is full (max reached)." }));
    return;
  }
  const player = {
    id: `p${++playerSeq}`,
    ws,
    name: sanitizeName(msg.name),
    color: msg.color || "Charcoal",
    eyes: msg.eyes || "Deadpan",
    mask: msg.mask || "Bandana",
    wallet: 0,
    won: [],
    targets: [],
    inventory: [],
    hasClaimedPowerUp: false,
    shieldActive: false,
    subpoenaed: false,
    endDiscussion: false,
    hasBid: false,
    currentBid: null,
  };
  if (isNew || room.players.length === 0) room.hostId = player.id;
  room.players.push(player);
  ws._room = room;
  ws._player = player;
  ws.send(JSON.stringify({ type: "joined", playerId: player.id, code: room.code }));
  broadcast(room, { type: "notice", text: `${player.name} joined the operation.` });
}

function findRandom(ws, msg) {
  const open = [...rooms.values()].find(
    (r) => r.mode === "public" && r.phase === "lobby" && r.players.length < r.playerLimit
  );
  if (!open) {
    ws.send(JSON.stringify({
      type: "error",
      text: "No public operation waiting. Create a private room instead — search never creates a room.",
    }));
    return;
  }
  joinRoom(ws, msg, open, false);
}

wss.on("connection", (ws) => {
  ws.on("message", (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }
    const room = ws._room;
    const player = ws._player;

    if (msg.type === "create") return createRoom(ws, msg);
    if (msg.type === "join") return joinRoom(ws, msg);
    if (msg.type === "find_random") return findRandom(ws, msg);
    if (!room || !player) return;

    if (msg.type === "chat") {
      if (room.phase !== "discussion") {
        ws.send(JSON.stringify({ type: "error", text: "Comms jammed — chat muted during silent bidding." }));
        return;
      }
      room.chat.push({ from: player.name, text: String(msg.text || "").slice(0, 300) });
      return broadcastState(room);
    }

    if (msg.type === "set_settings") {
      if (player.id !== room.hostId || room.phase !== "lobby") return;
      room.mode = msg.mode === "public" ? "public" : "private";
      room.playerLimit = Math.min(10, Math.max(2, msg.playerLimit || room.playerLimit));
      return broadcastState(room);
    }

    if (msg.type === "start") {
      if (player.id !== room.hostId || room.phase !== "lobby") return;
      if (room.players.length < 2) {
        ws.send(JSON.stringify({ type: "error", text: "At least 2 operatives required to initialize operation." }));
        return;
      }
      // Dynamic economic scaling locked strictly at START from actual connected players
      room.scaling = scalingFor(room.players.length);
      room.players.forEach((p) => { p.wallet = room.scaling.startingWallet; });
      return startDraft(room);
    }

    if (msg.type === "draft_select") {
      if (room.phase !== "draft") return;
      const name = String(msg.item || "");
      if (!ITEMS.some((i) => i.name === name)) return;
      if (player.targets.includes(name)) {
        player.targets = player.targets.filter((t) => t !== name);
      } else if (player.targets.length < 10) {
        player.targets.push(name);
      }
      return broadcastState(room);
    }

    if (msg.type === "end_discussion") {
      if (room.phase !== "discussion") return;
      player.endDiscussion = true;
      if (discussionShouldEnd(room.players.filter((p) => p.endDiscussion).length, room.players.length)) {
        return startBidding(room);
      }
      return broadcastState(room);
    }

    if (msg.type === "bid") {
      if (room.phase !== "bidding") return;
      const amount = Number(msg.amount);
      if (!isValidBid(amount, room.scaling.minBid, room.scaling.increment, player.wallet)) {
        ws.send(JSON.stringify({
          type: "error",
          text: `Invalid bid. Minimum ₹${room.scaling.minBid}, increment ₹${room.scaling.increment}, within wallet (₹${player.wallet}).`,
        }));
        return;
      }
      player.currentBid = amount;
      player.hasBid = true;
      return broadcastState(room);
    }

    // --- Black Market Speed-Snap Claim ---
    if (msg.type === "claim_power") {
      if (room.phase !== "black_market" || !room.blackMarket || !room.blackMarket.canClaim) {
        return;
      }
      if (room.blackMarket.claimedBy) {
        ws.send(JSON.stringify({ type: "error", text: "Card was already snapped by another operative!" }));
        return;
      }
      // Permanent Lockout Rule: player who claimed once cannot claim again this match
      if (player.hasClaimedPowerUp) {
        ws.send(JSON.stringify({
          type: "error",
          text: "Lockout active: Operatives may only claim one Black Market drop per operation.",
        }));
        return;
      }

      // First click wins!
      room.blackMarket.claimedBy = { id: player.id, name: player.name };
      room.blackMarket.canClaim = false;
      player.hasClaimedPowerUp = true;
      player.inventory.push(room.blackMarket.power.id);

      room.chat.push({
        from: "Broker",
        text: `⚡ SPEED-SNAP: ${player.name} secured the classified [${room.blackMarket.power.name}]!`,
      });
      broadcast(room, {
        type: "notice",
        text: `${player.name} claimed the ${room.blackMarket.power.name}! Locked out from future drops.`,
      });

      // Brief recap delay then transition
      clearTimer(room);
      startTimer(room, 3, () => {
        nextRoundOrEnd(room);
      });
      return;
    }

    // --- Tactical Power-Up Usage ---
    if (msg.type === "use_power") {
      const powerId = msg.power;
      const idx = player.inventory.indexOf(powerId);
      if (idx === -1) {
        ws.send(JSON.stringify({ type: "error", text: "You do not have that power card in your inventory." }));
        return;
      }

      if (powerId === "wiretap") {
        if (room.phase !== "discussion") {
          ws.send(JSON.stringify({ type: "error", text: "Wiretap can only be deployed during Discussion." }));
          return;
        }
        const target = room.players.find((p) => p.id === msg.targetId);
        if (!target || target.id === player.id) {
          ws.send(JSON.stringify({ type: "error", text: "Choose another operative to wiretap." }));
          return;
        }
        // Consume power-up
        player.inventory.splice(idx, 1);

        // Pick one target item from target's wishlist
        const wishlist = target.targets;
        const revealedItem = wishlist.length > 0
          ? wishlist[Math.floor(Math.random() * wishlist.length)]
          : "None selected";

        ws.send(JSON.stringify({
          type: "intel_revealed",
          title: "WIRETAP INTEL ACQUIRED",
          text: `Comms tapped on ${target.name}: They are hunting for [${revealedItem}]!`,
        }));

        room.chat.push({
          from: "Comms",
          text: `🕵️ Operative ${player.name} deployed a wiretap on ${target.name}.`,
        });
        broadcast(room, {
          type: "notice",
          text: `Wiretap executed: ${player.name} intercepted classified comms on ${target.name}!`,
        });
        return;
      }

      if (powerId === "subpoena") {
        if (room.phase !== "discussion" && room.phase !== "bidding") {
          ws.send(JSON.stringify({ type: "error", text: "Subpoena can be deployed in Discussion or Bidding." }));
          return;
        }
        const target = room.players.find((p) => p.id === msg.targetId);
        if (!target || target.id === player.id) {
          ws.send(JSON.stringify({ type: "error", text: "Choose another operative to subpoena." }));
          return;
        }
        player.inventory.splice(idx, 1);
        target.subpoenaed = true;

        room.chat.push({
          from: "Broker",
          text: `📋 SUBPOENA ENFORCED: ${target.name}'s wallet balance is ₹${target.wallet}!`,
        });
        broadcast(room, {
          type: "notice",
          text: `Subpoena issued: ${target.name}'s balance of ₹${target.wallet} is exposed!`,
        });
        return;
      }

      if (powerId === "shield") {
        if (room.phase !== "bidding" && room.phase !== "discussion") {
          ws.send(JSON.stringify({ type: "error", text: "Immunity Shield can only be armed before or during Bidding." }));
          return;
        }
        player.inventory.splice(idx, 1);
        player.shieldActive = true;

        ws.send(JSON.stringify({
          type: "intel_revealed",
          title: "IMMUNITY SHIELD ARMED",
          text: "Immunity Shield is active for this round's tie-breaker resolution.",
        }));
        room.chat.push({
          from: "Broker",
          text: `🛡️ Operative ${player.name} armed an Immunity Shield!`,
        });
        broadcast(room, {
          type: "notice",
          text: `${player.name} armed an Immunity Shield for Round ${room.round}!`,
        });
        return;
      }
    }
  });

  ws.on("close", () => {
    const room = ws._room;
    const player = ws._player;
    if (!room || !player) return;
    room.players = room.players.filter((p) => p.id !== player.id);
    if (room.players.length === 0) {
      clearTimer(room);
      rooms.delete(room.code);
      return;
    }
    if (room.hostId === player.id) {
      room.hostId = room.players[0].id;
    }
    broadcast(room, { type: "notice", text: `${player.name} disconnected from the syndicate.` });
  });
});

server.listen(PORT, () => {
  console.log(`Silent Bid server active on http://localhost:${PORT}`);
});
