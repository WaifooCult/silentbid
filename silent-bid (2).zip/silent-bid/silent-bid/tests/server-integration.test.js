import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  ITEMS, scalingFor, resolveBids, isBlackMarketRound, POWER_UPS,
} from "../game-logic.js";

describe("game flow & economy verification", () => {
  it("verifies dynamic scaling strictly matching spec table", () => {
    // 2 Players: 7 items, ₹15,000, ₹100 min, ₹100 inc
    const s2 = scalingFor(2);
    assert.equal(s2.itemsToWin, 7);
    assert.equal(s2.startingWallet, 15000);
    assert.equal(s2.minBid, 100);
    assert.equal(s2.increment, 100);

    // 3-4 Players: 5 items, ₹12,000, ₹200 min, ₹200 inc
    const s3 = scalingFor(3);
    const s4 = scalingFor(4);
    assert.equal(s3.itemsToWin, 5);
    assert.equal(s3.startingWallet, 12000);
    assert.equal(s4.itemsToWin, 5);
    assert.equal(s4.startingWallet, 12000);

    // 5-7 Players: 4 items, ₹10,000, ₹200 min, ₹200 inc
    const s5 = scalingFor(5);
    const s7 = scalingFor(7);
    assert.equal(s5.itemsToWin, 4);
    assert.equal(s5.startingWallet, 10000);
    assert.equal(s7.itemsToWin, 4);
    assert.equal(s7.startingWallet, 10000);

    // 8-10 Players: 3 items, ₹8,000, ₹200 min, ₹200 inc
    const s8 = scalingFor(8);
    const s10 = scalingFor(10);
    assert.equal(s8.itemsToWin, 3);
    assert.equal(s8.startingWallet, 8000);
    assert.equal(s10.itemsToWin, 3);
    assert.equal(s10.startingWallet, 8000);
  });

  it("verifies all 25 items exist with hints", () => {
    assert.equal(ITEMS.length, 25);
    for (const item of ITEMS) {
      assert.ok(item.name.length > 0);
      assert.ok(item.hint.length > 0);
    }
  });

  it("verifies black market drop schedule across all 25 rounds", () => {
    const drops = [];
    for (let r = 1; r <= 25; r++) {
      if (isBlackMarketRound(r)) drops.push(r);
    }
    assert.deepEqual(drops, [3, 6, 9, 12, 15, 18, 21, 24]);
  });

  it("verifies power-up card inventory and immunity shield resolution", () => {
    assert.equal(POWER_UPS.length, 3);
    const bids = [
      { playerId: "op1", amount: 1200 },
      { playerId: "op2", amount: 1200 },
      { playerId: "op3", amount: 400 },
    ];
    // Normally op3 wins (high tie -> lowest wins)
    const resNoShield = resolveBids(bids, 200, []);
    assert.equal(resNoShield.winnerId, "op3");

    // With Immunity Shield active on op1, op1 wins the high tie!
    const resShielded = resolveBids(bids, 200, ["op1"]);
    assert.equal(resShielded.winnerId, "op1");
    assert.equal(resShielded.rule, "shield_priority");
  });
});
